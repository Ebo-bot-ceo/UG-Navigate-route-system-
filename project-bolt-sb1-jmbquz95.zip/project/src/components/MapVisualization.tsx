import React from 'react';
import { Location, Route } from '../types';
import { MapPin, Navigation2 } from 'lucide-react';

interface MapVisualizationProps {
  locations: Location[];
  selectedRoute?: Route;
  fromLocation?: Location;
  toLocation?: Location;
}

const MapVisualization: React.FC<MapVisualizationProps> = ({
  locations,
  selectedRoute,
  fromLocation,
  toLocation
}) => {
  // Calculate view bounds
  const allX = locations.map(l => l.coordinates[0]);
  const allY = locations.map(l => l.coordinates[1]);
  const minX = Math.min(...allX) - 100;
  const maxX = Math.max(...allX) + 100;
  const minY = Math.min(...allY) - 100;
  const maxY = Math.max(...allY) + 100;
  const width = maxX - minX;
  const height = maxY - minY;

  // Convert coordinates to SVG coordinates
  const toSVG = (coord: [number, number]): [number, number] => {
    const x = ((coord[0] - minX) / width) * 800;
    const y = ((coord[1] - minY) / height) * 600;
    return [x, 600 - y]; // Flip Y axis
  };

  const getLocationColor = (location: Location): string => {
    if (fromLocation?.id === location.id) return '#10B981'; // Green for start
    if (toLocation?.id === location.id) return '#EF4444'; // Red for end
    if (selectedRoute?.path.some(p => p.id === location.id)) return '#3B82F6'; // Blue for path
    
    const colors = {
      academic: '#6366F1',
      residential: '#10B981',
      administrative: '#8B5CF6',
      recreational: '#F59E0B',
      service: '#EF4444',
      entrance: '#6B7280'
    };
    return colors[location.type];
  };

  const getLocationSize = (location: Location): number => {
    if (fromLocation?.id === location.id || toLocation?.id === location.id) return 8;
    if (selectedRoute?.path.some(p => p.id === location.id)) return 6;
    return 4;
  };

  return (
    <div className="bg-white border rounded-lg p-4">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold flex items-center gap-2">
          <Navigation2 size={20} />
          Campus Map
        </h2>
        <div className="text-xs text-gray-500">
          University of Ghana, Legon
        </div>
      </div>

      <div className="relative bg-gray-50 border rounded-lg overflow-hidden">
        <svg width="100%" height="400" viewBox="0 0 800 600" className="w-full">
          {/* Grid background */}
          <defs>
            <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
              <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#E5E7EB" strokeWidth="0.5"/>
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#grid)" />
          
          {/* Route path */}
          {selectedRoute && selectedRoute.path.length > 1 && (
            <g>
              {selectedRoute.path.slice(0, -1).map((location, index) => {
                const [x1, y1] = toSVG(location.coordinates);
                const [x2, y2] = toSVG(selectedRoute.path[index + 1].coordinates);
                return (
                  <line
                    key={`path-${index}`}
                    x1={x1}
                    y1={y1}
                    x2={x2}
                    y2={y2}
                    stroke="#3B82F6"
                    strokeWidth="3"
                    strokeDasharray="5,5"
                    opacity="0.8"
                  />
                );
              })}
              
              {/* Route direction arrows */}
              {selectedRoute.path.slice(0, -1).map((location, index) => {
                const [x1, y1] = toSVG(location.coordinates);
                const [x2, y2] = toSVG(selectedRoute.path[index + 1].coordinates);
                const midX = (x1 + x2) / 2;
                const midY = (y1 + y2) / 2;
                const angle = Math.atan2(y2 - y1, x2 - x1) * 180 / Math.PI;
                
                return (
                  <polygon
                    key={`arrow-${index}`}
                    points="0,-3 8,0 0,3"
                    fill="#3B82F6"
                    transform={`translate(${midX}, ${midY}) rotate(${angle})`}
                  />
                );
              })}
            </g>
          )}
          
          {/* Location points */}
          {locations.map((location) => {
            const [x, y] = toSVG(location.coordinates);
            const color = getLocationColor(location);
            const size = getLocationSize(location);
            
            return (
              <g key={location.id}>
                <circle
                  cx={x}
                  cy={y}
                  r={size}
                  fill={color}
                  stroke="white"
                  strokeWidth="2"
                  className="hover:r-6 transition-all duration-200 cursor-pointer"
                />
                <text
                  x={x}
                  y={y - size - 8}
                  textAnchor="middle"
                  className="text-xs font-medium fill-gray-700 pointer-events-none"
                  style={{ fontSize: '10px' }}
                >
                  {location.name.split(' ')[0]}
                </text>
              </g>
            );
          })}
        </svg>
      </div>

      {/* Legend */}
      <div className="mt-4 grid grid-cols-2 md:grid-cols-3 gap-3 text-xs">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 bg-green-500 rounded-full"></div>
          <span>Start Point</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 bg-red-500 rounded-full"></div>
          <span>Destination</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
          <span>Route Path</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 bg-indigo-500 rounded-full"></div>
          <span>Academic</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 bg-green-600 rounded-full"></div>
          <span>Residential</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 bg-amber-500 rounded-full"></div>
          <span>Services</span>
        </div>
      </div>
    </div>
  );
};

export default MapVisualization;