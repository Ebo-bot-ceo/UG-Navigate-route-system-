import React from 'react';
import { SortCriteria } from '../types';
import { Search, Filter, SortAsc } from 'lucide-react';

interface SearchFiltersProps {
  searchTerm: string;
  onSearchChange: (term: string) => void;
  sortCriteria: SortCriteria;
  onSortChange: (criteria: SortCriteria) => void;
  sortAlgorithm: string;
  onSortAlgorithmChange: (algorithm: string) => void;
}

const SearchFilters: React.FC<SearchFiltersProps> = ({
  searchTerm,
  onSearchChange,
  sortCriteria,
  onSortChange,
  sortAlgorithm,
  onSortAlgorithmChange
}) => {
  return (
    <div className="bg-white border rounded-lg p-4 space-y-4">
      <h3 className="font-semibold text-gray-900 flex items-center gap-2">
        <Filter size={18} />
        Search & Filter Options
      </h3>
      
      {/* Landmark Search */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Search by Landmark
        </label>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder="e.g., bank, hospital, library..."
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>
        {searchTerm && (
          <p className="mt-1 text-xs text-gray-600">
            Searching for routes near "{searchTerm}"
          </p>
        )}
      </div>

      {/* Sort Criteria */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Sort Routes By
          </label>
          <select
            value={sortCriteria}
            onChange={(e) => onSortChange(e.target.value as SortCriteria)}
            className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="distance">Shortest Distance</option>
            <option value="time">Fastest Time</option>
            <option value="landmarks">Most Landmarks</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Sorting Algorithm
          </label>
          <select
            value={sortAlgorithm}
            onChange={(e) => onSortAlgorithmChange(e.target.value)}
            className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="quicksort">Quick Sort</option>
            <option value="mergesort">Merge Sort</option>
            <option value="bubblesort">Bubble Sort</option>
          </select>
        </div>
      </div>

      {/* Algorithm Info */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
        <div className="flex items-center gap-2 mb-2">
          <SortAsc size={16} className="text-blue-600" />
          <h4 className="text-sm font-semibold text-blue-900">Algorithm Information</h4>
        </div>
        <div className="text-xs text-blue-800">
          {sortAlgorithm === 'quicksort' && (
            <p>Quick Sort: Average O(n log n), uses divide-and-conquer approach</p>
          )}
          {sortAlgorithm === 'mergesort' && (
            <p>Merge Sort: Guaranteed O(n log n), stable sorting algorithm</p>
          )}
          {sortAlgorithm === 'bubblesort' && (
            <p>Bubble Sort: O(n²), simple but less efficient for large datasets</p>
          )}
        </div>
      </div>
    </div>
  );
};

export default SearchFilters;