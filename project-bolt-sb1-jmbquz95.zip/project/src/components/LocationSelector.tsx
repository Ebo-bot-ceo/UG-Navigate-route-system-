import React from 'react';
import { Location } from '../types';
import { MapPin, Navigation } from 'lucide-react';

interface LocationSelectorProps {
  locations: Location[];
  selectedLocation: Location | null;
  onLocationSelect: (location: Location) => void;
  label: string;
  placeholder: string;
}

const LocationSelector: React.FC<LocationSelectorProps> = ({
  locations,
  selectedLocation,
  onLocationSelect,
  label,
  placeholder
}) => {
  const getTypeColor = (type: Location['type']) => {
    const colors = {
      academic: 'bg-blue-100 text-blue-800',
      residential: 'bg-green-100 text-green-800',
      administrative: 'bg-purple-100 text-purple-800',
      recreational: 'bg-orange-100 text-orange-800',
      service: 'bg-yellow-100 text-yellow-800',
      entrance: 'bg-gray-100 text-gray-800'
    };
    return colors[type];
  };

  return (
    <div className="flex flex-col space-y-2">
      <label className="text-sm font-medium text-gray-700 flex items-center gap-2">
        <Navigation size={16} />
        {label}
      </label>
      <div className="relative">
        <select
          value={selectedLocation?.id || ''}
          onChange={(e) => {
            const location = locations.find(l => l.id === e.target.value);
            if (location) onLocationSelect(location);
          }}
          className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent appearance-none bg-white"
        >
          <option value="">{placeholder}</option>
          {locations.map((location) => (
            <option key={location.id} value={location.id}>
              {location.name} ({location.type})
            </option>
          ))}
        </select>
        <MapPin className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
      </div>
      
      {selectedLocation && (
        <div className="p-3 bg-gray-50 rounded-lg">
          <div className="flex items-center justify-between mb-2">
            <h3 className="font-semibold text-gray-900">{selectedLocation.name}</h3>
            <span className={`px-2 py-1 rounded-full text-xs font-medium ${getTypeColor(selectedLocation.type)}`}>
              {selectedLocation.type}
            </span>
          </div>
          {selectedLocation.description && (
            <p className="text-sm text-gray-600 mb-2">{selectedLocation.description}</p>
          )}
          {selectedLocation.landmarks && selectedLocation.landmarks.length > 0 && (
            <div className="flex flex-wrap gap-1">
              {selectedLocation.landmarks.map((landmark, index) => (
                <span
                  key={index}
                  className="px-2 py-1 bg-blue-100 text-blue-700 text-xs rounded-full"
                >
                  {landmark}
                </span>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default LocationSelector;