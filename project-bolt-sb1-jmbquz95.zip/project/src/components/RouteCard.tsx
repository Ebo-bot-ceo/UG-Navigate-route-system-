import React from 'react';
import { Route } from '../types';
import { Clock, MapPin, Navigation, TrendingUp, Users } from 'lucide-react';

interface RouteCardProps {
  route: Route;
  isSelected?: boolean;
  onSelect?: () => void;
}

const RouteCard: React.FC<RouteCardProps> = ({ route, isSelected = false, onSelect }) => {
  const getTrafficColor = (traffic: Route['traffic']) => {
    const colors = {
      low: 'bg-green-100 text-green-800 border-green-200',
      medium: 'bg-yellow-100 text-yellow-800 border-yellow-200',
      high: 'bg-red-100 text-red-800 border-red-200'
    };
    return colors[traffic];
  };

  const getAlgorithmIcon = (algorithm: string) => {
    if (algorithm.includes('Dijkstra')) return <Navigation size={16} />;
    if (algorithm.includes('A*')) return <TrendingUp size={16} />;
    return <Users size={16} />;
  };

  return (
    <div
      className={`p-4 border rounded-lg cursor-pointer transition-all duration-200 ${
        isSelected
          ? 'border-blue-500 bg-blue-50 shadow-md'
          : 'border-gray-200 bg-white hover:border-blue-300 hover:shadow-sm'
      }`}
      onClick={onSelect}
    >
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-2">
          {getAlgorithmIcon(route.algorithm)}
          <h3 className="font-semibold text-gray-900">{route.algorithm}</h3>
        </div>
        <span className={`px-2 py-1 text-xs font-medium rounded-full border ${getTrafficColor(route.traffic)}`}>
          {route.traffic} traffic
        </span>
      </div>

      <div className="grid grid-cols-2 gap-4 mb-3">
        <div className="flex items-center gap-2">
          <MapPin size={16} className="text-gray-500" />
          <div>
            <p className="text-sm font-medium text-gray-900">{route.distance.toFixed(0)}m</p>
            <p className="text-xs text-gray-500">Distance</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Clock size={16} className="text-gray-500" />
          <div>
            <p className="text-sm font-medium text-gray-900">{route.estimatedTime.toFixed(0)} min</p>
            <p className="text-xs text-gray-500">Est. Time</p>
          </div>
        </div>
      </div>

      <div className="border-t pt-3">
        <h4 className="text-xs font-semibold text-gray-700 mb-2">Route Path</h4>
        <div className="flex items-center gap-1 text-xs text-gray-600 mb-2">
          {route.path.map((location, index) => (
            <React.Fragment key={location.id}>
              <span className="bg-gray-100 px-2 py-1 rounded">
                {location.name.split(' ')[0]}
              </span>
              {index < route.path.length - 1 && (
                <span className="text-gray-400">→</span>
              )}
            </React.Fragment>
          ))}
        </div>
        
        {route.landmarks.length > 0 && (
          <div>
            <h4 className="text-xs font-semibold text-gray-700 mb-1">Nearby Landmarks</h4>
            <div className="flex flex-wrap gap-1">
              {route.landmarks.slice(0, 4).map((landmark, index) => (
                <span
                  key={index}
                  className="px-1.5 py-0.5 bg-blue-100 text-blue-700 text-xs rounded"
                >
                  {landmark}
                </span>
              ))}
              {route.landmarks.length > 4 && (
                <span className="px-1.5 py-0.5 bg-gray-100 text-gray-600 text-xs rounded">
                  +{route.landmarks.length - 4} more
                </span>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default RouteCard;