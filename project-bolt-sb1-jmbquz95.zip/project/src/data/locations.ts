import { Location } from '../types';

export const ugLocations: Location[] = [
  // Academic Buildings
  {
    id: 'main-library',
    name: 'Balme Library',
    type: 'academic',
    coordinates: [0, 0], // Central reference point
    description: 'Main university library',
    landmarks: ['library', 'books', 'study']
  },
  {
    id: 'great-hall',
    name: 'Great Hall',
    type: 'academic',
    coordinates: [-200, -100],
    description: 'Main auditorium for ceremonies',
    landmarks: ['hall', 'ceremony', 'events']
  },
  {
    id: 'commonwealth-hall',
    name: 'Commonwealth Hall',
    type: 'residential',
    coordinates: [-400, 200],
    description: 'Student residential hall',
    landmarks: ['residence', 'hostel', 'accommodation']
  },
  {
    id: 'volta-hall',
    name: 'Volta Hall',
    type: 'residential',
    coordinates: [300, -300],
    description: 'Student residential hall',
    landmarks: ['residence', 'hostel', 'accommodation']
  },
  {
    id: 'legon-hall',
    name: 'Legon Hall',
    type: 'residential',
    coordinates: [400, 100],
    description: 'Student residential hall',
    landmarks: ['residence', 'hostel', 'accommodation']
  },
  // Academic Departments
  {
    id: 'computer-science',
    name: 'Department of Computer Science',
    type: 'academic',
    coordinates: [200, 200],
    description: 'Computer Science department',
    landmarks: ['computers', 'technology', 'IT']
  },
  {
    id: 'business-school',
    name: 'Business School',
    type: 'academic',
    coordinates: [-300, -200],
    description: 'University of Ghana Business School',
    landmarks: ['business', 'management', 'MBA']
  },
  {
    id: 'medical-school',
    name: 'Medical School',
    type: 'academic',
    coordinates: [500, -100],
    description: 'School of Medicine and Dentistry',
    landmarks: ['medicine', 'hospital', 'health']
  },
  // Administrative Buildings
  {
    id: 'vice-chancellor-office',
    name: "Vice Chancellor's Office",
    type: 'administrative',
    coordinates: [-100, -150],
    description: 'Main administrative building',
    landmarks: ['administration', 'office', 'management']
  },
  {
    id: 'registrar-office',
    name: "Registrar's Office",
    type: 'administrative',
    coordinates: [100, -200],
    description: 'Student records and registration',
    landmarks: ['registration', 'records', 'office']
  },
  // Services
  {
    id: 'ug-hospital',
    name: 'UG Hospital',
    type: 'service',
    coordinates: [600, 0],
    description: 'University hospital',
    landmarks: ['hospital', 'medical', 'health', 'emergency']
  },
  {
    id: 'night-market',
    name: 'Night Market',
    type: 'service',
    coordinates: [-500, 100],
    description: 'Campus food market',
    landmarks: ['food', 'market', 'restaurant', 'dining']
  },
  {
    id: 'bank',
    name: 'UG Bank',
    type: 'service',
    coordinates: [150, -100],
    description: 'Campus banking services',
    landmarks: ['bank', 'ATM', 'money', 'finance']
  },
  // Recreational
  {
    id: 'sports-stadium',
    name: 'Sports Stadium',
    type: 'recreational',
    coordinates: [-200, 300],
    description: 'Main sports complex',
    landmarks: ['sports', 'football', 'athletics', 'gym']
  },
  {
    id: 'swimming-pool',
    name: 'Swimming Pool',
    type: 'recreational',
    coordinates: [300, 250],
    description: 'University swimming facility',
    landmarks: ['swimming', 'pool', 'sports', 'recreation']
  },
  // Entrances
  {
    id: 'main-gate',
    name: 'Main Gate',
    type: 'entrance',
    coordinates: [-600, -200],
    description: 'Primary campus entrance',
    landmarks: ['entrance', 'gate', 'security']
  },
  {
    id: 'east-gate',
    name: 'East Gate',
    type: 'entrance',
    coordinates: [700, 200],
    description: 'Eastern campus entrance',
    landmarks: ['entrance', 'gate', 'security']
  }
];

// Create adjacency list for pathfinding
export const createAdjacencyList = () => {
  const adjacencyList = new Map<string, Array<{location: Location, distance: number}>>();
  
  ugLocations.forEach(location => {
    const neighbors: Array<{location: Location, distance: number}> = [];
    
    ugLocations.forEach(otherLocation => {
      if (location.id !== otherLocation.id) {
        const distance = Math.sqrt(
          Math.pow(location.coordinates[0] - otherLocation.coordinates[0], 2) +
          Math.pow(location.coordinates[1] - otherLocation.coordinates[1], 2)
        );
        
        // Only add as neighbors if distance is reasonable (not too far)
        if (distance < 500) {
          neighbors.push({ location: otherLocation, distance });
        }
      }
    });
    
    adjacencyList.set(location.id, neighbors);
  });
  
  return adjacencyList;
};