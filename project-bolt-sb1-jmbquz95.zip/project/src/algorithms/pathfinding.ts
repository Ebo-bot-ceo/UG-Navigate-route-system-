import { Location, PathfindingResult } from '../types';
import { ugLocations, createAdjacencyList } from '../data/locations';

// Priority Queue implementation for Dijkstra's algorithm
class PriorityQueue<T> {
  private items: Array<{ item: T; priority: number }> = [];

  enqueue(item: T, priority: number) {
    const queueItem = { item, priority };
    let added = false;

    for (let i = 0; i < this.items.length; i++) {
      if (queueItem.priority < this.items[i].priority) {
        this.items.splice(i, 0, queueItem);
        added = true;
        break;
      }
    }

    if (!added) {
      this.items.push(queueItem);
    }
  }

  dequeue(): T | undefined {
    return this.items.shift()?.item;
  }

  isEmpty(): boolean {
    return this.items.length === 0;
  }
}

// Dijkstra's Algorithm implementation
export const dijkstraAlgorithm = (start: Location, end: Location): PathfindingResult => {
  const adjacencyList = createAdjacencyList();
  const distances = new Map<string, number>();
  const previous = new Map<string, Location | null>();
  const pq = new PriorityQueue<Location>();

  // Initialize distances
  ugLocations.forEach(location => {
    distances.set(location.id, location.id === start.id ? 0 : Infinity);
    previous.set(location.id, null);
  });

  pq.enqueue(start, 0);

  while (!pq.isEmpty()) {
    const current = pq.dequeue();
    if (!current || current.id === end.id) break;

    const neighbors = adjacencyList.get(current.id) || [];
    
    for (const { location: neighbor, distance: edgeWeight } of neighbors) {
      const currentDistance = distances.get(current.id) || Infinity;
      const tentativeDistance = currentDistance + edgeWeight;
      
      if (tentativeDistance < (distances.get(neighbor.id) || Infinity)) {
        distances.set(neighbor.id, tentativeDistance);
        previous.set(neighbor.id, current);
        pq.enqueue(neighbor, tentativeDistance);
      }
    }
  }

  // Reconstruct path
  const path: Location[] = [];
  let currentNode: Location | null = end;
  
  while (currentNode) {
    path.unshift(currentNode);
    currentNode = previous.get(currentNode.id) || null;
  }

  return {
    path: path.length > 1 ? path : [start, end], // Fallback direct path if no route found
    distance: distances.get(end.id) || 0,
    algorithm: "Dijkstra's Algorithm"
  };
};

// A* Algorithm implementation
export const aStarAlgorithm = (start: Location, end: Location): PathfindingResult => {
  const adjacencyList = createAdjacencyList();
  const openSet = new PriorityQueue<Location>();
  const gScore = new Map<string, number>();
  const fScore = new Map<string, number>();
  const cameFrom = new Map<string, Location | null>();

  // Heuristic function (Euclidean distance)
  const heuristic = (a: Location, b: Location): number => {
    return Math.sqrt(
      Math.pow(a.coordinates[0] - b.coordinates[0], 2) +
      Math.pow(a.coordinates[1] - b.coordinates[1], 2)
    );
  };

  // Initialize scores
  ugLocations.forEach(location => {
    gScore.set(location.id, location.id === start.id ? 0 : Infinity);
    fScore.set(location.id, location.id === start.id ? heuristic(start, end) : Infinity);
    cameFrom.set(location.id, null);
  });

  openSet.enqueue(start, heuristic(start, end));

  while (!openSet.isEmpty()) {
    const current = openSet.dequeue();
    if (!current || current.id === end.id) break;

    const neighbors = adjacencyList.get(current.id) || [];
    
    for (const { location: neighbor, distance } of neighbors) {
      const tentativeGScore = (gScore.get(current.id) || Infinity) + distance;
      
      if (tentativeGScore < (gScore.get(neighbor.id) || Infinity)) {
        cameFrom.set(neighbor.id, current);
        gScore.set(neighbor.id, tentativeGScore);
        const newFScore = tentativeGScore + heuristic(neighbor, end);
        fScore.set(neighbor.id, newFScore);
        openSet.enqueue(neighbor, newFScore);
      }
    }
  }

  // Reconstruct path
  const path: Location[] = [];
  let currentNode: Location | null = end;
  
  while (currentNode) {
    path.unshift(currentNode);
    currentNode = cameFrom.get(currentNode.id) || null;
  }

  return {
    path: path.length > 1 ? path : [start, end],
    distance: gScore.get(end.id) || 0,
    algorithm: "A* Algorithm"
  };
};

// Greedy Best-First Search
export const greedyBestFirst = (start: Location, end: Location): PathfindingResult => {
  const adjacencyList = createAdjacencyList();
  const visited = new Set<string>();
  const path: Location[] = [start];
  let current = start;
  let totalDistance = 0;

  // Heuristic function (Euclidean distance)
  const heuristic = (a: Location, b: Location): number => {
    return Math.sqrt(
      Math.pow(a.coordinates[0] - b.coordinates[0], 2) +
      Math.pow(a.coordinates[1] - b.coordinates[1], 2)
    );
  };

  while (current.id !== end.id) {
    visited.add(current.id);
    const neighbors = adjacencyList.get(current.id) || [];
    
    // Filter unvisited neighbors
    const unvisitedNeighbors = neighbors.filter(
      ({ location }) => !visited.has(location.id)
    );
    
    if (unvisitedNeighbors.length === 0) break;
    
    // Find neighbor closest to destination
    const next = unvisitedNeighbors.reduce((best, neighbor) => {
      const currentHeuristic = heuristic(neighbor.location, end);
      const bestHeuristic = heuristic(best.location, end);
      return currentHeuristic < bestHeuristic ? neighbor : best;
    });
    
    totalDistance += next.distance;
    current = next.location;
    path.push(current);
  }

  return {
    path,
    distance: totalDistance,
    algorithm: "Greedy Best-First Search"
  };
};