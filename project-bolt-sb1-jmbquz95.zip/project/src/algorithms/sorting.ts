import { Route, SortCriteria } from '../types';

// Quick Sort implementation for routes
export const quickSort = (routes: Route[], criteria: SortCriteria): Route[] => {
  if (routes.length <= 1) return routes;

  const pivot = routes[Math.floor(routes.length / 2)];
  const left = routes.filter(route => compareRoutes(route, pivot, criteria) < 0);
  const middle = routes.filter(route => compareRoutes(route, pivot, criteria) === 0);
  const right = routes.filter(route => compareRoutes(route, pivot, criteria) > 0);

  return [...quickSort(left, criteria), ...middle, ...quickSort(right, criteria)];
};

// Merge Sort implementation for routes
export const mergeSort = (routes: Route[], criteria: SortCriteria): Route[] => {
  if (routes.length <= 1) return routes;

  const middle = Math.floor(routes.length / 2);
  const left = routes.slice(0, middle);
  const right = routes.slice(middle);

  return merge(mergeSort(left, criteria), mergeSort(right, criteria), criteria);
};

const merge = (left: Route[], right: Route[], criteria: SortCriteria): Route[] => {
  const result: Route[] = [];
  let leftIndex = 0;
  let rightIndex = 0;

  while (leftIndex < left.length && rightIndex < right.length) {
    if (compareRoutes(left[leftIndex], right[rightIndex], criteria) <= 0) {
      result.push(left[leftIndex]);
      leftIndex++;
    } else {
      result.push(right[rightIndex]);
      rightIndex++;
    }
  }

  return result.concat(left.slice(leftIndex)).concat(right.slice(rightIndex));
};

// Bubble Sort implementation (for educational purposes)
export const bubbleSort = (routes: Route[], criteria: SortCriteria): Route[] => {
  const sortedRoutes = [...routes];
  const n = sortedRoutes.length;

  for (let i = 0; i < n - 1; i++) {
    for (let j = 0; j < n - i - 1; j++) {
      if (compareRoutes(sortedRoutes[j], sortedRoutes[j + 1], criteria) > 0) {
        // Swap elements
        [sortedRoutes[j], sortedRoutes[j + 1]] = [sortedRoutes[j + 1], sortedRoutes[j]];
      }
    }
  }

  return sortedRoutes;
};

// Helper function to compare routes based on criteria
const compareRoutes = (a: Route, b: Route, criteria: SortCriteria): number => {
  switch (criteria) {
    case 'distance':
      return a.distance - b.distance;
    case 'time':
      return a.estimatedTime - b.estimatedTime;
    case 'landmarks':
      return a.landmarks.length - b.landmarks.length;
    default:
      return 0;
  }
};

// Binary Search implementation for finding routes
export const binarySearchRoutes = (
  sortedRoutes: Route[], 
  targetValue: number, 
  criteria: SortCriteria
): Route | null => {
  let left = 0;
  let right = sortedRoutes.length - 1;

  while (left <= right) {
    const middle = Math.floor((left + right) / 2);
    const middleValue = getRouteValue(sortedRoutes[middle], criteria);

    if (middleValue === targetValue) {
      return sortedRoutes[middle];
    } else if (middleValue < targetValue) {
      left = middle + 1;
    } else {
      right = middle - 1;
    }
  }

  return null;
};

const getRouteValue = (route: Route, criteria: SortCriteria): number => {
  switch (criteria) {
    case 'distance':
      return route.distance;
    case 'time':
      return route.estimatedTime;
    case 'landmarks':
      return route.landmarks.length;
    default:
      return 0;
  }
};