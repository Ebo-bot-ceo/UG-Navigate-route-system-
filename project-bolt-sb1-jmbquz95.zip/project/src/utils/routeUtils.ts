import { Location, Route } from '../types';
import { dijkstraAlgorithm, aStarAlgorithm, greedyBestFirst } from '../algorithms/pathfinding';

// Calculate estimated time based on distance and traffic
export const calculateEstimatedTime = (distance: number, traffic: 'low' | 'medium' | 'high'): number => {
  const baseSpeed = 5; // km/h walking speed
  const trafficMultipliers = {
    low: 1,
    medium: 1.3,
    high: 1.8
  };
  
  return (distance / 1000) * 60 / baseSpeed * trafficMultipliers[traffic]; // minutes
};

// Generate multiple routes using different algorithms
export const generateMultipleRoutes = (from: Location, to: Location): Route[] => {
  const routes: Route[] = [];
  const trafficLevels: Array<'low' | 'medium' | 'high'> = ['low', 'medium', 'high'];
  
  // Generate routes using different algorithms
  const algorithms = [
    { func: dijkstraAlgorithm, name: "Dijkstra's" },
    { func: aStarAlgorithm, name: "A*" },
    { func: greedyBestFirst, name: "Greedy" }
  ];
  
  algorithms.forEach((algo, index) => {
    const result = algo.func(from, to);
    const traffic = trafficLevels[index % trafficLevels.length];
    
    routes.push({
      id: `route-${algo.name}-${from.id}-${to.id}`,
      from,
      to,
      path: result.path,
      distance: result.distance,
      estimatedTime: calculateEstimatedTime(result.distance, traffic),
      algorithm: result.algorithm,
      traffic,
      landmarks: extractLandmarks(result.path)
    });
  });
  
  return routes;
};

// Extract landmarks from path
export const extractLandmarks = (path: Location[]): string[] => {
  const landmarks = new Set<string>();
  
  path.forEach(location => {
    if (location.landmarks) {
      location.landmarks.forEach(landmark => landmarks.add(landmark));
    }
  });
  
  return Array.from(landmarks);
};

// Filter routes by landmarks
export const filterRoutesByLandmark = (routes: Route[], landmark: string): Route[] => {
  return routes.filter(route => 
    route.landmarks.some(routeLandmark => 
      routeLandmark.toLowerCase().includes(landmark.toLowerCase())
    )
  );
};

// Calculate route efficiency score
export const calculateRouteScore = (route: Route): number => {
  const distanceScore = 1000 / (route.distance + 1); // Shorter is better
  const timeScore = 100 / (route.estimatedTime + 1); // Faster is better
  const landmarkScore = route.landmarks.length * 10; // More landmarks is better
  
  return distanceScore + timeScore + landmarkScore;
};