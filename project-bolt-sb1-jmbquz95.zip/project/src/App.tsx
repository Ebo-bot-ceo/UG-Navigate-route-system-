import React, { useState, useEffect, useMemo } from 'react';
import { Location, Route, SortCriteria } from './types';
import { ugLocations } from './data/locations';
import { generateMultipleRoutes, filterRoutesByLandmark } from './utils/routeUtils';
import { quickSort, mergeSort, bubbleSort } from './algorithms/sorting';

import LocationSelector from './components/LocationSelector';
import MapVisualization from './components/MapVisualization';
import RouteCard from './components/RouteCard';
import SearchFilters from './components/SearchFilters';

import { Navigation, MapPin, Clock, TrendingUp } from 'lucide-react';

function App() {
  const [fromLocation, setFromLocation] = useState<Location | null>(null);
  const [toLocation, setToLocation] = useState<Location | null>(null);
  const [routes, setRoutes] = useState<Route[]>([]);
  const [selectedRoute, setSelectedRoute] = useState<Route | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [sortCriteria, setSortCriteria] = useState<SortCriteria>('distance');
  const [sortAlgorithm, setSortAlgorithm] = useState('quicksort');
  const [isCalculating, setIsCalculating] = useState(false);

  // Generate routes when locations change
  useEffect(() => {
    if (fromLocation && toLocation && fromLocation.id !== toLocation.id) {
      setIsCalculating(true);
      
      // Simulate calculation time for demonstration
      setTimeout(() => {
        const newRoutes = generateMultipleRoutes(fromLocation, toLocation);
        setRoutes(newRoutes);
        setSelectedRoute(newRoutes[0]);
        setIsCalculating(false);
      }, 800);
    } else {
      setRoutes([]);
      setSelectedRoute(null);
    }
  }, [fromLocation, toLocation]);

  // Filter and sort routes
  const processedRoutes = useMemo(() => {
    let filteredRoutes = routes;

    // Filter by landmark search
    if (searchTerm.trim()) {
      filteredRoutes = filterRoutesByLandmark(routes, searchTerm);
    }

    // Sort routes using selected algorithm
    switch (sortAlgorithm) {
      case 'quicksort':
        return quickSort(filteredRoutes, sortCriteria);
      case 'mergesort':
        return mergeSort(filteredRoutes, sortCriteria);
      case 'bubblesort':
        return bubbleSort(filteredRoutes, sortCriteria);
      default:
        return filteredRoutes;
    }
  }, [routes, searchTerm, sortCriteria, sortAlgorithm]);

  const handleSwapLocations = () => {
    const temp = fromLocation;
    setFromLocation(toLocation);
    setToLocation(temp);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <Navigation className="h-8 w-8 text-blue-600" />
              <div>
                <h1 className="text-xl font-bold text-gray-900">UG Navigate</h1>
                <p className="text-sm text-gray-600">University of Ghana Campus Routing</p>
              </div>
            </div>
            <div className="flex items-center gap-4 text-sm text-gray-600">
              <div className="flex items-center gap-1">
                <MapPin size={16} />
                <span>Legon Campus</span>
              </div>
              <div className="flex items-center gap-1">
                <TrendingUp size={16} />
                <span>Live Traffic</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Panel - Controls */}
          <div className="lg:col-span-1 space-y-6">
            {/* Location Selection */}
            <div className="bg-white border rounded-lg p-6 space-y-4">
              <h2 className="text-lg font-semibold text-gray-900">Plan Your Route</h2>
              
              <LocationSelector
                locations={ugLocations}
                selectedLocation={fromLocation}
                onLocationSelect={setFromLocation}
                label="From"
                placeholder="Select starting location"
              />

              <div className="flex justify-center">
                <button
                  onClick={handleSwapLocations}
                  className="p-2 text-gray-500 hover:text-blue-600 hover:bg-blue-50 rounded-full transition-colors"
                  disabled={!fromLocation || !toLocation}
                >
                  <TrendingUp size={20} />
                </button>
              </div>

              <LocationSelector
                locations={ugLocations}
                selectedLocation={toLocation}
                onLocationSelect={setToLocation}
                label="To"
                placeholder="Select destination"
              />

              {fromLocation && toLocation && fromLocation.id !== toLocation.id && (
                <div className="pt-4 border-t">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-600">
                      {isCalculating ? 'Calculating routes...' : `${routes.length} routes found`}
                    </span>
                    {!isCalculating && routes.length > 0 && (
                      <div className="flex items-center gap-1 text-green-600">
                        <Clock size={14} />
                        <span>Real-time</span>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Search and Filters */}
            {routes.length > 0 && (
              <SearchFilters
                searchTerm={searchTerm}
                onSearchChange={setSearchTerm}
                sortCriteria={sortCriteria}
                onSortChange={setSortCriteria}
                sortAlgorithm={sortAlgorithm}
                onSortAlgorithmChange={setSortAlgorithm}
              />
            )}
          </div>

          {/* Center Panel - Map */}
          <div className="lg:col-span-1">
            <MapVisualization
              locations={ugLocations}
              selectedRoute={selectedRoute || undefined}
              fromLocation={fromLocation || undefined}
              toLocation={toLocation || undefined}
            />
          </div>

          {/* Right Panel - Routes */}
          <div className="lg:col-span-1">
            <div className="bg-white border rounded-lg p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">
                Route Options
                {processedRoutes.length > 0 && (
                  <span className="text-sm font-normal text-gray-600 ml-2">
                    ({processedRoutes.length} found)
                  </span>
                )}
              </h2>

              {isCalculating ? (
                <div className="space-y-4">
                  {[1, 2, 3].map(i => (
                    <div key={i} className="animate-pulse">
                      <div className="h-32 bg-gray-200 rounded-lg"></div>
                    </div>
                  ))}
                </div>
              ) : processedRoutes.length > 0 ? (
                <div className="space-y-4 max-h-96 overflow-y-auto">
                  {processedRoutes.map((route) => (
                    <RouteCard
                      key={route.id}
                      route={route}
                      isSelected={selectedRoute?.id === route.id}
                      onSelect={() => setSelectedRoute(route)}
                    />
                  ))}
                </div>
              ) : routes.length > 0 && searchTerm ? (
                <div className="text-center py-8">
                  <MapPin className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                  <h3 className="text-sm font-medium text-gray-900 mb-2">No routes found</h3>
                  <p className="text-sm text-gray-500">
                    No routes match your search for "{searchTerm}". Try a different landmark.
                  </p>
                </div>
              ) : (
                <div className="text-center py-8">
                  <Navigation className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                  <h3 className="text-sm font-medium text-gray-900 mb-2">Select Locations</h3>
                  <p className="text-sm text-gray-500">
                    Choose your starting point and destination to see available routes.
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Statistics Panel */}
        {selectedRoute && (
          <div className="mt-8 bg-white border rounded-lg p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Route Analysis</h2>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="text-center">
                <div className="text-2xl font-bold text-blue-600 mb-1">
                  {selectedRoute.distance.toFixed(0)}m
                </div>
                <div className="text-sm text-gray-600">Total Distance</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-green-600 mb-1">
                  {selectedRoute.estimatedTime.toFixed(0)} min
                </div>
                <div className="text-sm text-gray-600">Estimated Time</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-purple-600 mb-1">
                  {selectedRoute.path.length}
                </div>
                <div className="text-sm text-gray-600">Waypoints</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-orange-600 mb-1">
                  {selectedRoute.landmarks.length}
                </div>
                <div className="text-sm text-gray-600">Landmarks</div>
              </div>
            </div>
            <div className="mt-4 p-4 bg-gray-50 rounded-lg">
              <h3 className="font-semibold text-gray-900 mb-2">Algorithm Details</h3>
              <p className="text-sm text-gray-600">
                This route was calculated using <span className="font-medium">{selectedRoute.algorithm}</span> 
                {' '}with current <span className="font-medium">{selectedRoute.traffic} traffic</span> conditions.
                The route passes through {selectedRoute.path.length} locations and 
                {' '}{selectedRoute.landmarks.length} landmark categories.
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;