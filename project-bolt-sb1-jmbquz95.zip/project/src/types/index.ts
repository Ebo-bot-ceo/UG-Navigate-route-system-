export interface Location {
  id: string;
  name: string;
  type: 'academic' | 'residential' | 'administrative' | 'recreational' | 'service' | 'entrance';
  coordinates: [number, number];
  description?: string;
  landmarks?: string[];
}

export interface Route {
  id: string;
  from: Location;
  to: Location;
  path: Location[];
  distance: number;
  estimatedTime: number;
  algorithm: string;
  traffic: 'low' | 'medium' | 'high';
  landmarks: string[];
}

export interface PathfindingResult {
  path: Location[];
  distance: number;
  algorithm: string;
}

export type SortCriteria = 'distance' | 'time' | 'landmarks';